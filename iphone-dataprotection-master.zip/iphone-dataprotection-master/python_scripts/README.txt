Dependencies
	pycrypto (https://www.dlitz.net/software/pycrypto/)
	construct (http://construct.wikispaces.com/)