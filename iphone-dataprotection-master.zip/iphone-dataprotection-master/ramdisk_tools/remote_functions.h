
CFDictionaryRef load_system_keybag(int socket, CFDictionaryRef dict);
CFDictionaryRef bruteforce_system_keybag(int socket, CFDictionaryRef dict);
CFDictionaryRef keybag_get_passcode_key(int socket, CFDictionaryRef dict);
CFDictionaryRef get_escrow_record(int socket, CFDictionaryRef dict);
CFDictionaryRef download_file(int socket, CFDictionaryRef dict);
CFDictionaryRef remote_aes(int socket, CFDictionaryRef dict);
