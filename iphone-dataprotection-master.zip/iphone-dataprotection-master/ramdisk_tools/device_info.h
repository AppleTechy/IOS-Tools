#ifndef HGVERSION
#define HGVERSION "unknown"
#endif

CFMutableDictionaryRef device_info(int socket, CFDictionaryRef request);
