#/bin/sh

python python_scripts/usbmux/tcprelay.py -t 22:2222 

